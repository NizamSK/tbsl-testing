@include('website.common.header')

@include('website.common.menu')

@yield('content')

@include('website.common.footer')

@yield('custom_script')
