<?php echo $__env->make('admin.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Route::currentRouteName() != 'login'): ?>
    <?php echo $__env->make('admin.common.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.common.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('admin.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('customjs'); ?>
<?php echo $__env->yieldContent('graph'); ?>
<?php echo $__env->yieldContent('3dpiechart'); ?>
<?php echo $__env->yieldContent('donutchart'); ?>
<?php echo $__env->yieldContent('piechart'); ?>
<?php /**PATH /Users/ajitsingh/Desktop/TBSL/resources/views/admin/common/main.blade.php ENDPATH**/ ?>