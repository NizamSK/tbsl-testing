<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">LYSAGHT Leads</h4>
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Desktop</a></li>
                                <li class="breadcrumb-item active">All Lysaght Leads</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row-->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            

                            <table id="basic-datatable" class="table table-responsive wrap">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Profession</th>
                                        <th>Company Name</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>IP</th>
                                        <th>URL</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data['leads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($lead->name); ?></td>
                                            <td><?php echo e($lead->email); ?></td>
                                            <td><?php echo e($lead->phone); ?></td>
                                            <td><?php echo e($lead->profession); ?></td>
                                            <td><?php echo e($lead->company_name); ?></td>
                                            <td><?php echo e($lead->State->name); ?></td>
                                            <td><?php echo e($lead->City->name); ?></td>
                                            <td><?php echo e($lead->ip); ?></td>
                                            <td><?php echo e($lead->previous_url); ?></td>
                                            <td><?php echo e(date('d M, Y', strtotime($lead->created_at))); ?></td>
                                            <td>
                                                <span class="badge <?php if($lead->status == 0): ?> badge-danger <?php else: ?> badge-success <?php endif; ?> "><?php if($lead->status == 0): ?> Inactive <?php else: ?> Active <?php endif; ?></span>
                                            </td>
                                            <td style="display:flex">
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div> <!-- end card body-->
                    </div> <!-- end card -->
                </div><!-- end col-->
            </div>
            <!-- end row-->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.common.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ajitsingh/Desktop/TBSL/resources/views/admin/leads/lysaght.blade.php ENDPATH**/ ?>