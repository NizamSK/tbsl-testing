<table id="basic-datatable" class="table nowrap">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Profession</th>
            <th>Company Name</th>
            <th>State</th>
            <th>City</th>
            <th>IP</th>
            <th>URL</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data['leads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($lead->name); ?></td>
                <td><?php echo e($lead->email); ?></td>
                <td><?php echo e($lead->phone); ?></td>
                <td><?php echo e($lead->profession); ?></td>
                <td><?php echo e($lead->company_name); ?></td>
                <td><?php echo e($lead->State->name); ?></td>
                <td><?php echo e($lead->City->name); ?></td>
                <td><?php echo e($lead->ip); ?></td>
                <td><?php echo e($lead->previous_url); ?></td>
                <td><?php echo e(date('d M, Y', strtotime($lead->created_at))); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/ajitsingh/Desktop/TBSL/resources/views/admin/exports/durashine.blade.php ENDPATH**/ ?>