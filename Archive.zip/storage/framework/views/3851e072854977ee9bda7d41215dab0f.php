

<header id="page-topbar" style="background: linear-gradient(90deg, #fff 0%, #42A2B5 100%);color: #fff;">
    <div class="navbar-header">
        <!-- LOGO -->
        <div class="navbar-brand-box d-flex align-items-left">
            <a href="javascript:;" class="logo"><img src="<?php echo e(asset('website/assets/images/logo.png')); ?>" alt="Concentrix" width="80%" class="img-fluid"></a>


            <button type="button" class="btn btn-sm mr-2 font-size-16 d-lg-none header-item waves-effect waves-light" data-toggle="collapse" data-target="#topnav-menu-content">
                <i class="fa fa-fw fa-bars"></i>
            </button>
        </div>

        <div class="d-flex align-items-center">

            

            <div class="dropdown d-inline-block">
                <button type="button" class="btn header-item waves-effect waves-light" id="page-header-user-dropdown"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    
                    <span class="d-none d-sm-inline-block ml-1"><?php echo e(Auth::user()->name); ?></span>
                    <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-right">

                    <!-- item-->
                    <a href="" class="dropdown-item notify-item">
                        <i class="mdi mdi-onepassword mr-2"></i><span class="align-middle">Change Password</span>
                    </a>

                    <!-- item-->
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item notify-item">
                        <i class="mdi mdi-view-dashboard mr-2"></i><span class="align-middle">Logout</span>
                    </a>
                </div>
            </div>

            

        </div>
    </div>
</header>
<?php /**PATH /Users/ajitsingh/Desktop/TBSL/resources/views/admin/common/topbar.blade.php ENDPATH**/ ?>