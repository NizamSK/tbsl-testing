<div class="topnav">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

            <div class="collapse navbar-collapse" id="topnav-menu-content">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">
                            <i class="mdi mdi-view-dashboard mr-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-pages" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-google-pages mr-2"></i>Campaigns<div class="arrow-down"></div>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="topnav-pages">
                            <a href="<?php echo e(route('admin.lysaght')); ?>" class="dropdown-item">Lysaght</a>
                            <a href="<?php echo e(route('admin.durashine')); ?>" class="dropdown-item">Durashine</a>
                        </div>
                    </li>

                    



                    

                </ul>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH /Users/ajitsingh/Desktop/TBSL/resources/views/admin/common/navbar.blade.php ENDPATH**/ ?>